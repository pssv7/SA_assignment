#include "SomeContainedClass1.h"

SomeContainedClass1::SomeContainedClass1()
{
}
