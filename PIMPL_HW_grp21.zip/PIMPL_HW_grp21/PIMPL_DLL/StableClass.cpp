

#include "framework.h"
#include "StableClass.h"
#include "SomeContainedClass1.h"
#include "SomeContainedClass2.h"

class ClassImpl {
public:
    SomeContainedClass1* m_SomeContainedClass1;
    SomeContainedClass2* m_SomeContainedClass2;

    int CalculateDiff() {
        return m_SomeContainedClass1->getValue() - m_SomeContainedClass2->getValue();
    }
};

StableClass::StableClass(void) : s_Impl(new ClassImpl())
{
    s_Impl->m_SomeContainedClass1 = nullptr;
    s_Impl->m_SomeContainedClass2 = nullptr;
}

StableClass::~StableClass(void)
{
    delete s_Impl;
}


void StableClass::Method1(int i)
{

}

void StableClass::Method2(int i)
{

}

int StableClass::CalculateDiff() {
    return s_Impl->CalculateDiff();
}