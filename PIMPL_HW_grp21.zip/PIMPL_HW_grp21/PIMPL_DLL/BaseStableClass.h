#pragma once
class BaseStableClass
{
public:
	virtual void Method1(int i) = 0; 
	virtual void Method2(int i) = 0;

};

