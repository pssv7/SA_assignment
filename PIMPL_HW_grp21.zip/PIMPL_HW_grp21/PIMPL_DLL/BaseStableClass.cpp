#include "BaseStableClass.h"
