#include "SomeContainedClass2.h"

SomeContainedClass2::SomeContainedClass2()
{
}
