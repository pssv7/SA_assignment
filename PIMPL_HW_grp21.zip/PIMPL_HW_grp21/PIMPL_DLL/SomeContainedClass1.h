#pragma once
#include "PIMPLDLL_EXPORTS.h"

class PIMPLDLL_API SomeContainedClass1
{
public:
	SomeContainedClass1();
};

