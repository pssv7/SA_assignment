#pragma once
#include "PIMPLDLL_EXPORTS.h"

class PIMPLDLL_API SomeContainedClass2
{
public:
	SomeContainedClass2();

};

