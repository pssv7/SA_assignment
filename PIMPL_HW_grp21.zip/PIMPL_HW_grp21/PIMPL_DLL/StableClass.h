
#include "PIMPLDLL_EXPORTS.h"
#include "BaseStableClass.h"


class ClassImpl;

// This class is exported from the dll
class PIMPLDLL_API StableClass : BaseStableClass {
public:
	StableClass(void);
	~StableClass(void);

	void Method1(int i);
	void Method2(int i);

	int CalculateDiff();
	
private:
	ClassImpl* s_Impl;

};
